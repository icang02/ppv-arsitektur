<?php

namespace Database\Seeders;

use App\Models\FotoPrestasi;
use Illuminate\Database\Seeder;

class FotoPrestasiSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // FotoPrestasi::create([
        //     'prestasi_id' => 1,
        //     'foto' => 'foto1.jpg',
        // ]);
        // FotoPrestasi::create([
        //     'prestasi_id' => 1,
        //     'foto' => 'foto2.jpg',
        // ]);
        // FotoPrestasi::create([
        //     'prestasi_id' => 1,
        //     'foto' => 'foto3.jpg',
        // ]);
        // FotoPrestasi::create([
        //     'prestasi_id' => 2,
        //     'foto' => 'foto4.jpg',
        // ]);
    }
}
