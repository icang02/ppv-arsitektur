<div class="modal modal-video fade" id="videoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content rounded-0">
            <div class="modal-header">
                <h4 class="modal-title" id="exampleModalLabel">Profil D-III Arsitektur PPV UHO</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- 16:9 aspect ratio -->
                <div class="ratio ratio-16x9 shadow">
                    <iframe src="https://www.youtube.com/embed/fh6kChwFI_c?rel=0" frameborder="0" allowfullscreen
                        class="video"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>
